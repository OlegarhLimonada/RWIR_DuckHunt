using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Sceneloader_level2 : MonoBehaviour
{
    public void LoadScene()
    {
        SceneManager.LoadScene("LEVEL2");
    }
}
